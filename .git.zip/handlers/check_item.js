const CheckItemIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
        && handlerInput.requestEnvelope.request.intent.name === 'CheckItemIntent';
    },
    async handle(handlerInput) {
        const attributes = await handlerInput.attributesManager.getPersistentAttributes();
        const itemList = attributes.itemList;
        const itemNames = itemList.map(item => item.name).join(',');
        const speechText = itemNames + 'がメモされています';

        return handlerInput.responseBuilder
            .speak(speechText)
            .withSimpleCard('Hello World', speechText)
            .getResponse();;
    },
};

module.exports = CheckItemIntentHandler;